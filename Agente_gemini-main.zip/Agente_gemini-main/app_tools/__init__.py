from .clv import calculate_clv
from .churn import calculate_churn_risk
from .engagement import calculate_engagement
from .affinity import calculate_product_affinity
from .risk_profile import calculate_risk_profile

TOOLS = [
    calculate_clv,
    calculate_churn_risk,
    calculate_engagement,
    calculate_product_affinity,
    calculate_risk_profile,
]

